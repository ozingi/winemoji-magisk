﻿# winemoji-magisk
Fonts extracted from the latest DEV channel Windows built-in emoji fonts, Magisk brush into the experience and PC consistent emoji delivery experience. 
## 发布日志 2022.8.11
1. Windows emoji 字体版本1.35
##  简述
提取自最新dev频道Windows 自带的emoji字体，magisk刷入即可在Android获得和pc一致的emoji传递体验。
## 主要疗效
1. Moto 小部件（moto 天气和时钟）；
2. 可以修复类原生12L的多任务手势,此过程会将lawnchair设为默认多任务手势，这会和QuickSwitch模块冲突，使用前先卸载QuickSwitch模块；
3. sony最新的几套动态壁纸。
### 🥰如果喜欢你也可以请我喝果汁🥰
### [打赏 / Donate](https://ozingi.github.io/img/payment/Alipay.jpg)
<img alt="图片笑死了" style="width:40% " src="https://ozingi.github.io/img/payment/Alipay.jpg"/>

### 推广
[进入web3领取最高1万元数字礼包](https://ozingi.github.io/html/AD/crypto.html)